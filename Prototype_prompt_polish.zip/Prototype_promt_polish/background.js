chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "save-selection") return;

  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });

    if (!tab?.id) return;

    // Extract selected text
    const result = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const active = document.activeElement;

        if (
          active &&
          (active.tagName === "TEXTAREA" || active.tagName === "INPUT")
        ) {
          const start = active.selectionStart;
          const end = active.selectionEnd;

          if (start !== null && end !== null) {
            return active.value.substring(start, end).trim();
          }
        }

        return window.getSelection().toString().trim();
      }
    });

    const text = result?.[0]?.result;
    if (!text) return;

    // 🔹 Loading UI
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      args: [text],
      func: (original) => {
        const old = document.getElementById("prompt-popup");
        if (old) old.remove();

        const container = document.createElement("div");
        container.id = "prompt-popup";

        Object.assign(container.style, {
          position: "fixed",
          bottom: "20px",
          right: "20px",
          width: "420px",
          maxHeight: "70vh",
          background: "#1e1e1e",
          color: "#fff",
          padding: "14px",
          borderRadius: "12px",
          zIndex: 999999,
          boxShadow: "0 8px 24px rgba(0,0,0,0.5)",
          fontSize: "14px",
          lineHeight: "1.5",
          overflow: "auto" // ✅ FIXED
        });

        container.innerHTML = `
          ⏳ Improving your prompt...
          <div style="margin-top:8px; opacity:0.6;">
            ${original}
          </div>
        `;

        document.body.appendChild(container);
      }
    });

    // 🔥 Backend call
    const response = await fetch(
      "https://promptpolish-prompt-optimization-chrome.onrender.com/process",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ text })
      }
    );

    if (!response.ok) throw new Error("Server error");

    const data = await response.json();
    const improvedText = data.result;

    if (!improvedText) throw new Error("Empty response");

    // 🔹 Final UI
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      args: [text, improvedText],
      func: (original, improved) => {
        const container = document.getElementById("prompt-popup");
        if (!container) return;

        container.innerHTML = `
          <div style="
            display:flex;
            flex-direction:column;
            gap:10px;
            font-family:system-ui;
          ">

            <div style="font-size:15px; font-weight:600;">
              ✨ Prompt Improved
            </div>

            <div style="font-size:12px; opacity:0.6;">Original</div>
            <div style="
              background:#2a2a2a;
              padding:8px;
              border-radius:8px;
              max-height:120px;
              overflow:auto;
              font-size:13px;
            ">${original}</div>

            <div style="font-size:12px; opacity:0.6;">Improved</div>
            <div style="
              background:#1f3a2f;
              padding:10px;
              border-radius:8px;
              max-height:150px;
              overflow:auto;
              font-size:13px;
            ">${improved}</div>

            <!-- ✅ BUTTONS FIXED -->
            <div style="
              display:flex;
              gap:8px;
              margin-top:10px;
              position:sticky;
              bottom:0;
              background:#1e1e1e;
              padding-top:6px;
            ">
              <button id="copy-btn">Copy</button>
              <button id="replace-btn">Replace</button>
              <button id="close-btn">✕</button>
            </div>

          </div>
        `;

        const styleBtn = (btn, bg) => {
          Object.assign(btn.style, {
            flex: "1",
            padding: "8px",
            border: "none",
            borderRadius: "8px",
            background: bg,
            color: "white",
            cursor: "pointer"
          });

          btn.onmouseenter = () => btn.style.opacity = "0.85";
          btn.onmouseleave = () => btn.style.opacity = "1";
        };

        const copyBtn = document.getElementById("copy-btn");
        const replaceBtn = document.getElementById("replace-btn");
        const closeBtn = document.getElementById("close-btn");

        styleBtn(copyBtn, "#4CAF50");
        styleBtn(replaceBtn, "#2196F3");
        styleBtn(closeBtn, "#444");

        // COPY
        copyBtn.onclick = async () => {
          await navigator.clipboard.writeText(improved);
          copyBtn.textContent = "Copied ✓";
          setTimeout(() => container.remove(), 900);
        };

        // REPLACE
        replaceBtn.onclick = () => {
          const el = document.activeElement;
          if (!el) return;

          if (
            el.tagName === "TEXTAREA" ||
            el.tagName === "INPUT"
          ) {
            const start = el.selectionStart || 0;
            const end = el.selectionEnd || 0;

            el.value =
              el.value.slice(0, start) +
              improved +
              el.value.slice(end);

            container.remove();
          } else {
            navigator.clipboard.writeText(improved);
            alert("Copied. Press Ctrl+V.");
            container.remove();
          }
        };

        // CLOSE
        closeBtn.onclick = () => container.remove();
      }
    });

  } catch (err) {
    console.error(err);

    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });

    if (!tab?.id) return;

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      args: [err.message],
      func: (message) => {
        const container = document.getElementById("prompt-popup");
        if (!container) return;

        container.innerHTML = `
          ❌ Error
          <div style="margin-top:6px;">${message}</div>
        `;
      }
    });
  }
});